// src/store/useTodoStore.ts
import { create } from "zustand";

interface Todo {
  text: string;
  completed: boolean;
}

interface TodoStore {
  todos: Todo[];
  showModal: boolean;
  modalMessage: string;
  addTodo: (newTodo: string) => void;
  deleteTodo: (deleteIdx: number) => void;
  updateTodo: (updateIdx: number, newValue: string) => void;
  completeTodo: (completedIdx: number) => void;
  setTodos: (newTodos: Todo[]) => void;
  openModal: (message: string) => void;
  closeModal: () => void;
}

const useTodoStore = create<TodoStore>((set) => ({
  todos: [],
  showModal: false,
  modalMessage: "",

  addTodo: (newTodo: string) =>
    set((state) => ({
      todos: [...state.todos, { text: newTodo, completed: false }],
    })),

  deleteTodo: (deleteIdx: number) =>
    set((state) => ({
      todos: state.todos.filter((_, idx) => idx !== deleteIdx),
    })),

  updateTodo: (updateIdx: number, newValue: string) =>
    set((state) => ({
      todos: state.todos.map((todo, idx) =>
        idx === updateIdx ? { ...todo, text: newValue } : todo
      ),
    })),

  completeTodo: (completedIdx: number) =>
    set((state) => ({
      todos: state.todos.map((todo, idx) =>
        idx === completedIdx ? { ...todo, completed: !todo.completed } : todo
      ),
    })),

  setTodos: (newTodos: Todo[]) =>
    set(() => ({
      todos: newTodos,
    })),

  openModal: (message: string) =>
    set(() => ({
      showModal: true,
      modalMessage: message,
    })),

  closeModal: () =>
    set(() => ({
      showModal: false,
      modalMessage: "",
    })),
}));

export default useTodoStore;
