import React, { useRef } from "react";
import useTodoStore from "../store/useTodoStore"; // zustand 스토어 import

function TodoInput() {
  const inputRef = useRef<HTMLInputElement>(null); // useRef로 input DOM 요소 참조

  // zustand로부터 상태와 함수를 가져옵니다
  const { todos, addTodo, openModal } = useTodoStore();

  const handleAddTodo = () => {
    const newTodo = inputRef.current?.value.trim(); // 입력값을 가져옴

    if (!newTodo) {
      openModal("[추가 실패] 값을 입력해주세요"); // 모달 알림
      return;
    }

    addTodo(newTodo); // zustand에서 상태를 추가
    if (inputRef.current) inputRef.current.value = ""; // 입력 필드를 빈 문자열로 초기화
  };

  // Enter 눌렀을 때 handleAddTodo 호출
  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleAddTodo();
    }
  };

  return (
    <div className="flex items-center w-full p-2 bg-white shadow-md rounded-lg">
      <input
        ref={inputRef} // input 요소에 ref 연결
        type="text"
        placeholder="what needs to be done?"
        onKeyUp={handleKeyPress} // Enter 키 이벤트 처리
        className="flex-1 p-2 border border-blue-400 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
      />
      <button
        onClick={handleAddTodo}
        className="ml-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-500 transition-all duration-300 ease-in-out"
      >
        +
      </button>
    </div>
  );
}

export default TodoInput;
