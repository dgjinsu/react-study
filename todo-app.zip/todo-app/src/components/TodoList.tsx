import useTodoStore from "../store/useTodoStore"; // zustand 스토어 import
import TodoItem from "./TodoItem";

function TodoList() {
  const { todos } = useTodoStore();

  return (
    <ul>
      {todos.map((todo, idx) => (
        <TodoItem todo={todo} key={idx} idx={idx} />
      ))}
    </ul>
  );
}

export default TodoList;
