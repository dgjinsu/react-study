import TodoItem from "./TodoItem";

function TodoList({ todos, deleteTodo, updateTodo, completeTodo, openModal }) {
  return (
    <ul>
      {todos.map((todo, idx) => (
        <TodoItem
          key={idx}
          todo={todo}
          updateTodo={(newValue) => updateTodo(idx, newValue)} // 업데이트
          deleteTodo={() => deleteTodo(idx)} // 삭제
          completeTodo={() => completeTodo(idx)}
          openModal={openModal}
        ></TodoItem>
      ))}
    </ul>
  );
}

export default TodoList;
