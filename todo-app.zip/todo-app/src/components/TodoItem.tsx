import React, { useState, useRef } from "react";
import { RiEdit2Line } from "react-icons/ri";
import useTodoStore from "../store/useTodoStore"; // zustand 스토어 import

interface TodoItemProps {
  todo: {
    text: string;
    completed: boolean;
  };
  idx: number;
}

function TodoItem({ todo, idx }: TodoItemProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isEditing, setIsEditing] = useState(false); // 수정 모드 여부

  // zustand에서 상태와 함수를 가져옴
  const { updateTodo, deleteTodo, completeTodo, openModal } = useTodoStore();

  const handleSave = () => {
    const newValue = inputRef.current?.value.trim();

    if (!newValue) {
      openModal("[수정 실패] 값을 입력해주세요."); // 입력값이 비어있을 때 모달 호출
      return;
    }

    updateTodo(idx, newValue); // zustand에서 updateTodo 호출
    setIsEditing(false); // 수정 모드 종료
  };

  // Enter 키를 누르면 저장
  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleSave();
    }
  };

  return (
    <li className="flex p-2 bg-white border-b border-gray-300 rounded-md">
      {/* 체크박스 */}
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => completeTodo(idx)} // zustand에서 completeTodo 호출
        className="mr-2 h-5 w-5 cursor-pointer"
      />

      {/* 텍스트 수정 가능 영역 */}
      {!isEditing ? (
        <span
          className={`text-left ${
            todo.completed ? "line-through text-gray-500" : ""
          }`}
        >
          {todo.text}
        </span>
      ) : (
        <input
          ref={inputRef} // ref 연결
          defaultValue={todo.text}
          onKeyDown={handleKeyPress} // Enter 키 입력 시 처리
          onBlur={handleSave} // 입력 필드에서 벗어날 때 값 저장
          className="flex-1 p-1 border border-gray-300 rounded-md text-left"
        />
      )}

      {/* 아이콘들을 감싸는 div */}
      <div className="ml-auto flex">
        {/* 수정 아이콘 */}
        <RiEdit2Line
          onClick={() => setIsEditing(true)} // 수정 모드 활성화
          className="text-blue-500 cursor-pointer mr-2"
        />

        {/* 삭제 버튼 */}
        <button onClick={() => deleteTodo(idx)} className="cursor-pointer">
          ✖
        </button>
      </div>
    </li>
  );
}

export default TodoItem;
