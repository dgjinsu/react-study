import React from "react";

interface ModalProps {
  show: boolean;
  onClose: () => void;
  message: string;
}

function Modal({ show, onClose, message }: ModalProps) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      {/* 
        fixed: 화면에 고정하여 스크롤에도 움직이지 않도록 함
        bg-black bg-opacity-50: 배경을 검정색 50% 투명도로 설정
        flex, items-center, justify-center: 모달을 화면 중앙에 배치
      */}
      <div className="bg-white p-6 rounded-md shadow-lg max-w-sm w-full">
        <p className="mb-4 text-center">{message}</p>
        <button
          onClick={onClose}
          className="w-full bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors duration-300"
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default Modal;
