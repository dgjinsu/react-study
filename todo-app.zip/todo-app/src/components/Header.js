import React from "react";

function Header() {
  return (
    <header className="text-3xl font-bold text-gray-600 tracking-wide">
      TODOLIST
    </header>
  );
}

export default Header;
