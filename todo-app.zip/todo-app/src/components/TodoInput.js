import React, { useRef } from "react";

function TodoInput({ todos, setTodos, openModal }) {
  const inputRef = useRef(null); // useRef로 input DOM 요소 참조

  const addTodo = () => {
    const newTodo = inputRef.current.value.trim(); // 입력값을 가져옴

    if (newTodo === "") {
      openModal("[추가 실패] 값을 입력해주세요"); // 모달 알림
      return;
    }

    setTodos([...todos, { text: newTodo, completed: false }]); // todos에 추가
    inputRef.current.value = ""; // 입력 필드를 빈 문자열로 초기화
  };

  // Enter 눌렀을 때 addTodo 호출
  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      addTodo();
    }
  };

  return (
    <div className="flex items-center w-full p-2 bg-white shadow-md rounded-lg">
      <input
        ref={inputRef} // input 요소에 ref 연결
        type="text"
        placeholder="what needs to be done?"
        onKeyUp={handleKeyPress} // Enter 키 이벤트 처리
        className="flex-1 p-2 border border-blue-400 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
      />
      <button
        onClick={addTodo}
        className="ml-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-500 transition-all duration-300 ease-in-out"
      >
        +
      </button>
    </div>
  );
}

export default TodoInput;
