import useTodoStore from "../store/useTodoStore"; // zustand 스토어 import

function TodoStatus() {
  const { todos, setTodos } = useTodoStore();

  const getDoneTodoNum = () => {
    return todos.filter((todo) => todo.completed).length;
  };

  const getAllTodoNum = () => {
    return todos.length;
  };

  const doneTodoNum = getDoneTodoNum();
  const allTodoNum = getAllTodoNum();
  const progressPercentage =
    allTodoNum > 0 ? (doneTodoNum / allTodoNum) * 100 : 0; // 0 이상일 때 progresspercentage 계산

  // 완료 비율에 따라 색상 계산 (빨간색 -> 주황색 -> 초록색)
  const getProgressColor = () => {
    const red = Math.max(255 - Math.round((progressPercentage / 100) * 255), 0);
    const green = Math.min(Math.round((progressPercentage / 100) * 255), 255);
    return `rgb(${red}, ${green}, 0)`; // 빨간색에서 초록색으로 자연스러운 색상 변화
  };

  // 체크된 항목을 제거
  const removeCheckedTodos = () => {
    const filteredTodos = todos.filter((todo) => !todo.completed);
    setTodos(filteredTodos); // 완료된 항목을 제거한 후 상태 업데이트
  };

  return (
    <div className="w-full mt-6 flex items-center justify-between">
      {/* 프로그레스 바 */}
      <div className="flex items-center w-3/5">
        {/* 
          flex: 자식 요소들을 가로로 나란히 배치
          items-center: 세로 축에서 자식 요소들을 중앙에 배치
          w-3/5: 부모 요소의 너비를 60%로 설정
        */}
        <div className="relative w-full bg-gray-300 rounded-sm h-6">
          {/* 
            relative: 자식 요소의 절대 위치를 기준으로 삼기 위한 위치 설정
            w-full: 부모 요소의 전체 너비를 차지하게 설정
            bg-gray-300: 배경 색상을 밝은 회색(#d1d5db)으로 설정
            rounded-sm: 모서리를 작게 둥글게 설정
            h-6: 높이를 6단위(1.5rem, 24px)로 설정
          */}
          <div
            className="absolute top-0 left-0 h-6 rounded-lg transition-all duration-1000 ease-in-out"
            style={{
              width: `${progressPercentage}%`,
              backgroundColor: getProgressColor(),
            }}
          ></div>
          <div className="absolute inset-0 items-center justify-center text-gray-700 font-bold">
            {/* 
              absolute: 부모 요소(`relative` 설정된 요소) 기준으로 절대 위치 설정
              inset-0: 부모 요소의 모든 방향에서 0 거리로 설정
              justify-center: 자식 요소를 가로 중앙 정렬
              items-center: 자식 요소를 세로 중앙 정렬
            */}
            {doneTodoNum} of {allTodoNum} tasks done
          </div>
        </div>
      </div>

      {/* 완료된 항목 제거 버튼 */}
      <div className="flex justify-end w-1/3">
        <button
          onClick={removeCheckedTodos}
          className="bg-blue-500 text-white px-4 py-2 rounded-sm hover:bg-blue-500"
        >
          Remove Checked ✖
        </button>
      </div>
    </div>
  );
}

export default TodoStatus;
