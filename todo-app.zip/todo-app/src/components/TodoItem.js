import React, { useState, useRef } from "react";
import { RiEdit2Line } from "react-icons/ri";

function TodoItem({ todo, deleteTodo, updateTodo, completeTodo, openModal }) {
  const inputRef = useRef(null);
  const [isEditing, setIsEditing] = useState(false); // 수정 모드 여부

  const handleSave = () => {
    const newValue = inputRef.current.value.trim();

    if (newValue === "") {
      openModal("[수정 실패] 값을 입력해주세요."); // 입력값이 비어있을 때 모달 호출
      return;
    }

    updateTodo(newValue); // 업데이트
    setIsEditing(false); // 수정 모드 종료
  };

  // Enter 키를 누르면 저장
  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      handleSave();
    }
  };

  return (
    <li className="flex p-2 bg-white border-b border-gray-300 rounded-md">
      {/* 
        flex: 리스트 항목을 가로로 나란히 배치
      */}

      {/* 체크박스 */}
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={completeTodo}
        className="mr-2 h-5 w-5 cursor-pointer"
      />

      {/* 텍스트 수정 가능 영역 */}
      {!isEditing ? (
        <span
          className={`text-left ${
            todo.completed ? "line-through text-gray-500" : ""
          }`}
        >
          {/* 
            line-through: 할 일이 완료되면 취소선
          */}
          {todo.text}
        </span>
      ) : (
        <input
          ref={inputRef} // ref 연결
          defaultValue={todo.text}
          onKeyDown={handleKeyPress} // Enter 키 입력 시 처리
          onBlur={handleSave} // 입력 필드에서 벗어날 때 값 저장
          className="flex-1 p-1 border border-gray-300 rounded-md text-left"
        />
      )}
      {/* 
        flex-1: 입력 필드가 남은 공간을 모두 차지하도록 설정
      */}

      {/* 아이콘들을 감싸는 div */}
      <div className="ml-auto flex">
        {/* 
          ml-auto: 텍스트와 아이콘 사이에 공간을 자동으로 확보, 아이콘을 오른쪽으로 밀어냄
          flex: 아이콘들을 가로로 나란히 배치
        */}

        {/* 수정 아이콘 */}
        <RiEdit2Line
          onClick={() => setIsEditing(true)}
          className="text-blue-500 cursor-pointer mr-2"
        />

        {/* 삭제 아이콘 */}
        <button onClick={deleteTodo} className="cursor-pointer">
          ✖
        </button>
      </div>
    </li>
  );
}

export default TodoItem;
