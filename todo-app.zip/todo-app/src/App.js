import { useState } from "react";
import "./App.css";
import TodoList from "./components/TodoList";
import TodoInput from "./components/TodoInput";
import TodoStatus from "./components/TodoStatus";
import Header from "./components/Header";
import Modal from "./components/Modal";
function App() {
  // { text: newTodo, completed: false }
  const [todos, setTodos] = useState([]); // 할 일 목록
  const [showModal, setShowModal] = useState(false); // 모달 상태 관리
  const [modalMessage, setModalMessage] = useState(""); // 모달 메시지 상태 관리

  const deleteTodo = (deleteIdx) => {
    console.log("delete 함수 진입");
    const tempTodos = todos.filter((todo, idx) => idx !== deleteIdx);
    setTodos(tempTodos);
  };

  const updateTodo = (updateIdx, newValue) => {
    console.log("update 함수 진입");

    const tempTodos = todos.map((todo, idx) => {
      if (idx === updateIdx) {
        return { ...todo, text: newValue }; // todo 객체에서 text 값만 수정
      }
      return todo;
    });

    setTodos(tempTodos);
  };

  const completeTodo = (completedIdx) => {
    console.log("완료한 TODO 상태 업데이트");
    const updatedTodos = todos.map((todo, idx) =>
      idx === completedIdx ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos); // 상태를 업데이트
  };

  const openModal = (message) => {
    setModalMessage(message); // 메시지 설정
    setShowModal(true); // 모달 열기
  };
  const closeModal = () => setShowModal(false);

  return (
    <div className="App w-1/3 mx-auto my-10 bg-ivory p-6 rounded-lg shadow-lg">
      <Header />

      <TodoInput todos={todos} setTodos={setTodos} openModal={openModal} />

      <TodoList
        todos={todos}
        deleteTodo={deleteTodo}
        updateTodo={updateTodo}
        completeTodo={completeTodo}
        openModal={openModal}
      />

      <TodoStatus todos={todos} setTodos={setTodos} />

      {/* Modal */}
      {/* 상위 컴포넌트에서 Modal을 호출해야 z-index 없이 사용 가능 */}
      <Modal show={showModal} onClose={closeModal} message={modalMessage} />
    </div>
  );
}

export default App;
