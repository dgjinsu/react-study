export interface TodoType {
  todoId: number;
  content: string;
  isCompleted: boolean;
}
