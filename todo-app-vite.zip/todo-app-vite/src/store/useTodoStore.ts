import { create } from "zustand";
import { TodoType } from "@src/types";

interface TodoStore {
  todos: TodoType[];
  editingId: number | null; // 현재 수정 중인 todo의 id
  setEditingId: (id: number | null) => void;
  addTodo: (newTodo: string) => void;
  deleteTodo: (deleteId: number) => void;
  updateTodo: (updateId: number, newValue: string) => void;
  completeTodo: (completeId: number) => void;
  setTodos: (newTodos: TodoType[]) => void;
}

const useTodoStore = create<TodoStore>((set) => ({
  todos: [],
  editingId: null,

  setEditingId: (id: number | null) => set({ editingId: id }),

  addTodo: (newTodo: string) =>
    set((state) => ({
      todos: [
        ...state.todos,
        { todoId: Date.now(), content: newTodo, isCompleted: false },
      ],
    })),

  deleteTodo: (deleteId: number) =>
    set((state) => ({
      todos: state.todos.filter((todo) => todo.todoId !== deleteId),
    })),

  updateTodo: (updateId: number, newValue: string) =>
    set((state) => ({
      todos: state.todos.map((todo) =>
        todo.todoId === updateId ? { ...todo, text: newValue } : todo
      ),
    })),

  completeTodo: (completeId: number) =>
    set((state) => ({
      todos: state.todos.map((todo) =>
        todo.todoId === completeId
          ? { ...todo, completed: !todo.isCompleted }
          : todo
      ),
    })),

  setTodos: (newTodos: TodoType[]) => set({ todos: newTodos }),
}));

export default useTodoStore;
