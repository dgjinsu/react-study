import { create } from "zustand";

interface ModalStore {
  showModal: boolean;
  modalMessage: string;
  openModal: (message: string) => void;
  closeModal: () => void;
}

const useModalStore = create<ModalStore>((set) => ({
  showModal: false,
  modalMessage: "",

  openModal: (message: string) =>
    set(() => ({
      showModal: true,
      modalMessage: message,
    })),

  closeModal: () =>
    set(() => ({
      showModal: false,
      modalMessage: "",
    })),
}));

export default useModalStore;
