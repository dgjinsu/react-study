import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

// 특정 Todo 삭제 API 호출 함수
const deleteTodoById = async (todoId: number): Promise<void> => {
  await axios.delete(`http://localhost:8080/api/v1/todo/${todoId}`);
};

// 특정 Todo 삭제 커스텀 훅
export function useDeleteTodo() {
  const queryClient = useQueryClient();
  return useMutation<void, Error, number>({
    mutationFn: deleteTodoById,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["todos"] }); // 완료 후 목록 갱신
      console.log("TODO 삭제 성공");
    },
    onError: (error: Error) => {
      console.error(`삭제 중 오류가 발생했습니다: ${error.message}`);
    },
  });
}
