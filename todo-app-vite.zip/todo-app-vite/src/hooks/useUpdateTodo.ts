import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

interface UpdateTodoRequest {
  content: string;
  isComplete: boolean;
}

// Todo 업데이트 API 호출 함수
const updateTodoContent = async (
  todoId: number,
  requestData: UpdateTodoRequest
): Promise<void> => {
  await axios.put(`http://localhost:8080/api/v1/todo/${todoId}`, requestData);
};

// Todo 업데이트 커스텀 훅
export function useUpdateTodo() {
  const queryClient = useQueryClient();
  return useMutation<
    void,
    Error,
    { todoId: number; requestData: UpdateTodoRequest }
  >({
    mutationFn: ({ todoId, requestData }) =>
      updateTodoContent(todoId, requestData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["todos"] });
      console.log("업데이트 완료");
    },
    onError: (error: Error) => {
      console.error(`수정 중 오류가 발생했습니다: ${error.message}`);
    },
  });
}
