import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

// 완료된 Todo 삭제 API 호출 함수
const deleteCompletedTodos = async (): Promise<void> => {
  await axios.delete("http://localhost:8080/api/v1/todo/completed");
};

// 완료된 Todo 삭제 커스텀 훅
export function useDeleteCompletedTodos() {
  const queryClient = useQueryClient();
  return useMutation<void, Error>({
    mutationFn: deleteCompletedTodos,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["todos"] });
      console.log("삭제 완료");
    },
    onError: (error: Error) => {
      console.error(`삭제 중 오류가 발생했습니다: ${error.message}`);
    },
  });
}
