import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { TodoType } from "@src/types";

// API 응답 타입 정의
interface TodoListResponse {
  data: {
    todoListResponseList: TodoType[];
    totalTodoNum: number;
    completedTodoNum: number;
  };
  message: string;
}

// Todo 목록 조회 API 호출 함수
const fetchTodos = async (): Promise<TodoListResponse> => {
  const response = await axios.get<TodoListResponse>(
    "http://localhost:8080/api/v1/todos"
  );
  return response.data;
};

// Todo 목록 조회 커스텀 훅
export function useTodos() {
  return useQuery<TodoListResponse, Error>({
    queryKey: ["todos"],
    queryFn: fetchTodos,
  });
}
