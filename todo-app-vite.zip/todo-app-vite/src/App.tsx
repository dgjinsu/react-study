import { Header, Todo } from "@src/components";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// QueryClient 객체 생성
const queryClient = new QueryClient();

function App() {
  return (
    <div className="App w-1/3 mx-auto my-10 bg-ivory p-6 rounded-lg shadow-lg text-center">
      <Header />

      <QueryClientProvider client={queryClient}>
        <Todo />
      </QueryClientProvider>
    </div>
  );
}

export default App;
