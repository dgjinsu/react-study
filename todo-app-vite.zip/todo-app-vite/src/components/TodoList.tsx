import { TodoItem } from "@src/components";
import { TodoType } from "@src/types";

interface TodoListProps {
  todos: TodoType[];
  updateTodo: (todoId: number, content: string, isCompleted: boolean) => void;
  deleteTodo: (todoId: number) => void;
  editingId: number | null;
  setEditingId: (todoId: number | null) => void;
  openModal: (message: string) => void;
}

function TodoList({
  todos,
  updateTodo,
  deleteTodo,
  editingId,
  setEditingId,
  openModal,
}: TodoListProps) {
  return (
    <ul>
      {todos.map((todo) => (
        <TodoItem
          key={todo.todoId}
          todo={todo}
          updateTodo={updateTodo}
          deleteTodo={deleteTodo}
          editingId={editingId}
          setEditingId={setEditingId}
          openModal={openModal}
        />
      ))}
    </ul>
  );
}

export default TodoList;
