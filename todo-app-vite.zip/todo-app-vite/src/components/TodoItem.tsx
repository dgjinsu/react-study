import React, { useRef, useEffect } from "react";
import { RiEdit2Line } from "react-icons/ri";
import { TodoType } from "@src/types";

interface TodoItemProps {
  todo: TodoType;
  updateTodo: (todoId: number, content: string, isCompleted: boolean) => void;
  deleteTodo: (todoId: number) => void;
  editingId: number | null;
  setEditingId: (todoId: number | null) => void;
  openModal: (message: string) => void;
}

function TodoItem({
  todo,
  updateTodo,
  deleteTodo,
  editingId,
  setEditingId,
  openModal,
}: TodoItemProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSave = (
    event?: React.FormEvent | React.ChangeEvent<HTMLInputElement>
  ) => {
    event?.preventDefault();

    const isCheckbox =
      event?.target instanceof HTMLInputElement &&
      event.target.type === "checkbox";

    // 체크박스에서 호출된 경우
    if (isCheckbox) {
      updateTodo(todo.todoId, todo.content, !todo.isCompleted);
    } else {
      // 입력 필드에서 호출된 경우
      const newValue = inputRef.current?.value.trim();
      if (!newValue) {
        openModal("[수정 실패] 값을 입력해주세요.");
        return;
      }
      updateTodo(todo.todoId, newValue, todo.isCompleted);
      setEditingId(null); // 수정 모드 종료
    }
  };

  // 수정 중인 Item 인지 확인
  const isEditing = editingId === todo.todoId;

  // isEditing이 true일 경우 실행
  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus(); // 수정 모드일 때 input에 포커스
    }
  }, [isEditing]);

  return (
    <li className="flex p-2 bg-white border-b border-gray-300 rounded-md">
      <input
        type="checkbox"
        checked={todo.isCompleted}
        onChange={handleSave}
        className="mr-2 h-5 w-5 cursor-pointer"
      />

      {!isEditing ? (
        <span
          className={`text-left ${
            todo.isCompleted ? "line-through text-gray-500" : ""
          }`}
        >
          {todo.content}
        </span>
      ) : (
        <form onSubmit={handleSave} className="flex-1">
          <input
            ref={inputRef}
            defaultValue={todo.content}
            onBlur={handleSave} // 포커스가 벗어났을 때 form 제출
            className="w-full p-1 border border-gray-300 rounded-md text-left"
          />
        </form>
      )}

      <div className="ml-auto flex">
        <RiEdit2Line
          onClick={() => setEditingId(todo.todoId)} // 수정 모드 활성화
          className="text-blue-500 cursor-pointer mr-2"
        />

        <button
          onClick={() => deleteTodo(todo.todoId)}
          className="cursor-pointer"
        >
          ✖
        </button>
      </div>
    </li>
  );
}

export default TodoItem;
