import { TodoInput, TodoList, TodoFooter, Modal } from "@src/components";
import { useRef, useEffect } from "react";
import useTodoStore from "@src/store/useTodoStore";
import useModalStore from "@src/store/useModalStore";
import {
  useTodos,
  useDeleteTodo,
  useUpdateTodo,
  useDeleteCompletedTodos,
} from "@src/hooks";

function Todo() {
  const inputRef = useRef<HTMLInputElement>(null);

  // Todo 관련 상태와 메서드
  const todos = useTodoStore((state) => state.todos);
  const setTodos = useTodoStore((state) => state.setTodos);
  const editingId = useTodoStore((state) => state.editingId);
  const setEditingId = useTodoStore((state) => state.setEditingId);

  // Modal 관련 상태와 메서드
  const showModal = useModalStore((state) => state.showModal);
  const modalMessage = useModalStore((state) => state.modalMessage);
  const openModal = useModalStore((state) => state.openModal);
  const closeModal = useModalStore((state) => state.closeModal);

  // Custom hooks를 사용한 API 호출
  const { data, error } = useTodos();
  const { mutate: removeCheckedTodos } = useDeleteCompletedTodos();
  const { mutate: updateTodoMutation } = useUpdateTodo();
  const { mutate: deleteTodoMutation } = useDeleteTodo();

  // 데이터가 변경될 때만 setTodos 호출
  useEffect(() => {
    if (data) {
      setTodos(data.data.todoListResponseList);
    }
  }, [data]);

  // 에러 핸들링
  if (error) {
    openModal(`TODO 목록을 불러오는 중 오류가 발생했습니다: ${error.message}`);
  }

  return (
    <div>
      <TodoInput inputRef={inputRef} openModal={openModal} />
      <TodoList
        todos={todos}
        updateTodo={(todoId, content, isCompleted) =>
          updateTodoMutation({
            todoId: todoId,
            requestData: { content: content, isComplete: isCompleted },
          })
        }
        deleteTodo={(todoId) => deleteTodoMutation(todoId)}
        editingId={editingId}
        setEditingId={setEditingId}
        openModal={openModal}
      />
      <TodoFooter todos={todos} removeCheckedTodos={removeCheckedTodos} />
      {showModal && (
        <Modal modalMessage={modalMessage} closeModal={closeModal} />
      )}
    </div>
  );
}

export default Todo;
