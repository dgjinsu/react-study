interface RemoveCheckedButtonProps {
  removeCheckedTodos: () => void;
}

function RemoveCheckedButton({ removeCheckedTodos }: RemoveCheckedButtonProps) {
  return (
    <div className="flex justify-end w-1/3">
      <button
        onClick={removeCheckedTodos}
        className="bg-blue-500 text-white px-4 py-2 rounded-sm hover:bg-blue-500"
      >
        Remove Checked ✖
      </button>
    </div>
  );
}

export default RemoveCheckedButton;
