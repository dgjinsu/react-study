import React, { RefObject } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

interface TodoInputProps {
  inputRef: RefObject<HTMLInputElement>;
  openModal: (message: string) => void;
}

// API 응답 타입
interface TodoSaveResponse {
  data: number;
  message: string;
}

// 요청 API 정의
const saveTodo = async (content: string): Promise<TodoSaveResponse> => {
  const response = await axios.post<TodoSaveResponse>(
    "http://localhost:8080/api/v1/todo",
    { content }
  );
  return response.data;
};

function TodoInput({ inputRef, openModal }: TodoInputProps) {
  const queryClient = useQueryClient();

  // 새로운 TODO 저장 API 요청
  const addTodoMutation = useMutation<TodoSaveResponse, Error, string>({
    mutationFn: saveTodo,
    onSuccess: () => {
      // 성공 시: todos 목록을 다시 불러와 최신 상태 유지
      queryClient.invalidateQueries({ queryKey: ["todos"] });
      console.log("TODO 추가 성공");
    },
    onError: (error) => {
      // 오류 발생 시: 사용자에게 오류 메시지 표시
      openModal(`오류 발생: ${error.message}`);
    },
  });

  // form submit 이벤트 처리
  const handleSubmit = (event?: React.FormEvent) => {
    if (event) {
      event.preventDefault();
    }

    const newTodo = inputRef.current?.value.trim(); // 입력값을 가져옴

    if (!newTodo || newTodo === "") {
      openModal("[추가 실패] 값을 입력해주세요");
      return;
    }

    // API 호출
    addTodoMutation.mutate(newTodo);

    if (inputRef.current) inputRef.current.value = ""; // 입력 필드 초기화
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-center w-full p-2 bg-white shadow-md rounded-lg"
    >
      <input
        ref={inputRef} // input 요소에 ref 연결
        type="text"
        placeholder="what needs to be done?"
        className="flex-1 p-2 border border-blue-400 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
      />
      <button
        type="submit"
        className="ml-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-500 transition-all duration-300 ease-in-out"
      >
        +
      </button>
    </form>
  );
}

export default TodoInput;
