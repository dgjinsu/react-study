interface ModalProps {
  modalMessage: string;
  closeModal: () => void;
}

function Modal({ modalMessage, closeModal }: ModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-md shadow-lg max-w-sm w-full">
        <p className="mb-4 text-center">{modalMessage}</p>
        <button
          onClick={closeModal}
          className="w-full bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors duration-300"
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default Modal;
