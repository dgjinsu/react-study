import { TodoStatus, RemoveCheckedButton } from "@src/components";
import { TodoType } from "@src/types";

interface TodoFooterProps {
  todos: TodoType[];
  removeCheckedTodos: () => void;
}

function TodoFooter({ todos, removeCheckedTodos }: TodoFooterProps) {
  return (
    <div className="w-full mt-6 flex items-center justify-between">
      <TodoStatus todos={todos} />

      {/* 완료된 항목 제거 버튼 컴포넌트 */}
      {/* some: 배열에 특정 조건을 만족하는 요소가 하나라도 있는지 확인하는 메서드 */}
      {todos.some((todo) => todo.isCompleted) && (
        <RemoveCheckedButton removeCheckedTodos={removeCheckedTodos} />
      )}
    </div>
  );
}

export default TodoFooter;
